define({
  "_widgetLabel": "Kontroler nagłówka",
  "signin": "Zaloguj",
  "signout": "Wyloguj",
  "about": "Informacje o",
  "signInTo": "Zaloguj się do",
  "cantSignOutTip": "Funkcja nie ma zastosowania w widoku podglądu.",
  "more": "więcej"
});